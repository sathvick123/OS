#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/processinfo.h"
int
main(int argc,char* argv[])
{
        struct processinfo pInfo;
        get_process_info(&pInfo);
        printf("Process ID -> %d\n",pInfo.pid);
        printf("Process Name -> %s\n",pInfo.name);
        printf("Memory Size -> %d\n",pInfo.sz);
        exit(0);
}
